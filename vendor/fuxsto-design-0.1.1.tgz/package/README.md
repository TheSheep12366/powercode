# fuxsto-design

Monochrome zinc, Tailwind CSS v4 component library for Vue 3.

> 从 furry-tattoo 项目中独立剥离的 Vue 3 UI 组件库。主题完全可自定义 —— 配色与圆角均走 CSS 设计令牌（`--primary` / `--radius` 等），发布包默认值是一套克制的 zinc 黑白灰。内置亮/暗双主题、统一出厂动画、loading 扫光、disabled 灰化，移动端自适应。40+ 组件、50+ 子路径导出，支持按需引入与 tree-shaking。

## 安装

```bash
npm install fuxsto-design
```

### 依赖要求

| 依赖 | 说明 |
|------|------|
| `vue` | `^3.5.0` |
| `tailwindcss` | `^4.0.0` |
| `lucide-vue-next` | `^0.577.0`（图标库，组件内部使用） |

这三个是 **peer dependencies**，需要你的项目自行安装。

## 使用方式

### 方式一：Tailwind CSS v4 用户（推荐）

在你的样式文件中：

```css
@import "tailwindcss";
@import "fuxsto-design/styles";
```

然后按需引入组件：

```vue
<script setup>
import { Button, Card, Input, Message } from 'fuxsto-design'
</script>
```

你也可以通过子路径按组件引入，实现 tree-shaking：

```js
import Button from 'fuxsto-design/button'
import Card from 'fuxsto-design/card'
import Input from 'fuxsto-design/input'
```

### 方式二：不使用 Tailwind 的用户

直接引入组件库自带的完整样式表：

```js
import 'fuxsto-design/fuxsto.css'
```

> 两种方式二选一，切勿混用。

## 组件列表

### 基础组件 (Base)
| 组件 | 导出名 | 子路径 |
|------|--------|--------|
| 按钮 | `Button` | `fuxsto-design/button` |
| 按钮组 | `ButtonGroup` | `fuxsto-design/button-group` |
| 卡片 | `Card` | `fuxsto-design/card` |
| 标签纸片 | `Chip` / `Tag` | `fuxsto-design/chip` |
| 纸片组 | `ChipGroup` / `TagGroup` | `fuxsto-design/chip-group` |
| 徽标 | `Badge` | `fuxsto-design/badge` |
| 头像 | `Avatar` | `fuxsto-design/avatar` |
| 头像组 | `AvatarGroup` | `fuxsto-design/avatar-group` |
| 分割线 | `Divider` | `fuxsto-design/divider` |
| 选项卡 | `Tabs` | `fuxsto-design/tabs` |
| 选项卡视图 | `TabViews` | `fuxsto-design/tab-views` |
| 菜单 | `Menu` | `fuxsto-design/menu` |
| 右键菜单 | `ContextMenu` | `fuxsto-design/context-menu` |
| 表格 | `Table` | `fuxsto-design/table` |
| 分页器 | `Pagination` | `fuxsto-design/pagination` |
| 列表 | `List` | `fuxsto-design/list` |
| 列表项 | `ListItem` | `fuxsto-design/list-item` |
| 折叠面板 | `Collapse` | `fuxsto-design/collapse` |
| 折叠项 | `CollapseItem` | `fuxsto-design/collapse-item` |
| 步骤条 | `Steps` | `fuxsto-design/steps` |
| 分段控制器 | `Segmented` | `fuxsto-design/segmented` |

### 导航 (Navigation)
| 组件 | 导出名 | 子路径 |
|------|--------|--------|
| 面包屑 | `Breadcrumb` | `fuxsto-design/breadcrumb` |
| 面包屑项 | `BreadcrumbItem` | `fuxsto-design/breadcrumb-item` |
| 页头 | `Header` | `fuxsto-design/header` |

### 表单 (Form)
| 组件 | 导出名 | 子路径 |
|------|--------|--------|
| 表单容器 | `Form` | `fuxsto-design/form` |
| 表单项 | `FormItem` | `fuxsto-design/form-item` |
| 输入框 | `Input` | `fuxsto-design/input` |
| 验证码 | `PinInput` | `fuxsto-design/pin-input` |
| 开关 | `Switch` | `fuxsto-design/switch` |
| 单选 | `Radio` | `fuxsto-design/radio` |
| 单选组 | `RadioGroup` | `fuxsto-design/radio-group` |
| 多选 | `Checkbox` | `fuxsto-design/checkbox` |
| 多选组 | `CheckboxGroup` | `fuxsto-design/checkbox-group` |
| 下拉选择 | `Select` | `fuxsto-design/select` |
| 自动补全 | `AutoComplete` | `fuxsto-design/auto-complete` |

### 数据展示 (Data)
| 组件 | 导出名 | 子路径 |
|------|--------|--------|
| 进度条 | `Progress` | `fuxsto-design/progress` |
| 数值统计 | `Statistic` | `fuxsto-design/statistic` |
| 时间轴 | `Timeline` | `fuxsto-design/timeline` |
| 时间轴项 | `TimelineItem` | `fuxsto-design/timeline-item` |

### 反馈 (Feedback)
| 组件 | 导出名 | 子路径 |
|------|--------|--------|
| 消息提示 | `Message` | `fuxsto-design/message` |
| 通知 | `Notification` | `fuxsto-design/notification` |
| 对话框 | `DialogComponent` / `Dialog` | `fuxsto-design/dialog` |
| 抽屉 | `Drawer` | `fuxsto-design/drawer` |
| 气泡提示 | `Tooltip` | `fuxsto-design/tooltip` |
| 气泡确认 | `Popconfirm` | `fuxsto-design/popconfirm` |
| 空状态 | `Empty` | `fuxsto-design/empty` |
| 加载包裹 | `Loading` | `fuxsto-design/loading` |
| 骨架屏 | `Skeleton` | `fuxsto-design/skeleton` |
| 结果页 | `Result` | `fuxsto-design/result` |
| 回到顶部 | `BackTop` | `fuxsto-design/back-top` |

### 工具
| 导出 | 子路径 |
|------|--------|
| `cn` | `fuxsto-design/cn` |

## 快速开始

```vue
<script setup lang="ts">
import { Button, Input, Card, Message, Dialog } from 'fuxsto-design'
import { Sparkles } from 'lucide-vue-next'

const name = ref('')

const handleClick = () => {
  Message.success(`你好，${name.value || '世界'}！`)
}
</script>

<template>
  <Card variant="default" shadow="md" padding="md">
    <template #header>卡片标题</template>
    <Input v-model="name" placeholder="请输入你的名字" clearable />
    <Button variant="primary" :icon="Sparkles" @click="handleClick">
      点击我
    </Button>
  </Card>
</template>
```

## 主题

组件库内置亮/暗双主题，通过 CSS 变量驱动。暗色模式支持两种触发方式：

1. **跟随系统**：`@media (prefers-color-scheme: dark)` 自动生效
2. **手动切换**：给 `<html>` 添加 `.dark` 类

```js
// 手动切换暗色
document.documentElement.classList.toggle('dark')
```

## 开发

```bash
# 启动演示页
npm run dev

# 构建库
npm run build

# 类型检查
npm run type-check
```

## License

MIT